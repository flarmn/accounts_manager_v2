<template>
  <div>
    <!-- Заголовок таблицы -->
    <AccountsTableHeading />

    <!-- Строки таблицы -->
    <AccountsTableRows
      v-for="(acct, idx) in accounts"
      :key="acct.id"
      :index="idx"
      :account="acct"
      :fieldErrors="errors[idx] || {}"
      :passwordVisible="passwordVisible[idx] || false"
      @update-label="$emit('update-label', ...arguments)"
      @update-field="$emit('update-field', ...arguments)"
      @validate-field="$emit('validate', ...arguments)"
      @toggle-password="$emit('toggle-password', ...arguments)"
      @remove="$emit('remove', idx)"
    />
  </div>
</template>

<script setup>
// eslint-disable-next-line no-undef
defineProps({
  accounts: {
    type: Array,
    required: true
  },
  errors: {
    type: Object,
    required: true
  },
  passwordVisible: {
    type: Object,
    required: true
  }
});
// eslint-disable-next-line no-undef
defineEmits([
  'update-label',
  'update-field',
  'validate',
  'toggle-password',
  'remove'
]);

import AccountsTableHeading from '@/components/AccountsTable/AccountsTableHeading.vue';
import AccountsTableRows   from '@/components/AccountsTable/AccountsTableRows.vue';
</script>

<style scoped>
/* Здесь можно указать scoped-стили, если понадобятся */
</style>
