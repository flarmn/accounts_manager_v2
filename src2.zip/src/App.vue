<template>
  <div class="accounts-form">
    <!-- Заголовок с кнопкой “+” -->
    <AccountsHeader @add="addAccount" />

    <!-- Информационное сообщение -->
    <InfoMessage />

    <!-- Основная таблица (заголовок + строки) -->
    <AccountsTableMain
      :accounts="accounts"
      :errors="errors"
      :passwordVisible="passwordVisible"
      @update-label="updateLabel"
      @update-field="updateField"
      @validate="validateField"
      @toggle-password="togglePasswordVisibility"
      @remove="removeAccount"
    />
  </div>
</template>

<script setup>
import { computed, reactive } from 'vue';
import { useAccountsStore } from '@/stores/accountsStore';
import AccountsHeader from '@/components/AccountsHeader.vue';
import InfoMessage from '@/components/InfoMessage.vue';
import AccountsTableMain from '@/components/AccountsTable/AccountsTableMain.vue';
import { validateLogin, validatePassword } from '@/services/validators';

// Pinia-стор
const store = useAccountsStore();
const accounts = computed(() => store.accounts);

// Ошибки валидации для каждой записи (ключи — индексы)
const errors = reactive({});

// Видимость пароля для каждой записи (ключи — индексы)
const passwordVisible = reactive({});

/**
 * Добавляет новую учетную запись (вызывается по @add из AccountsHeader)
 */
function addAccount() {
  store.addAccount();
}

/**
 * Удаляет запись: принимает index (должно быть числом)
 */
function removeAccount(index) {
  
  console.log('App.vue/removeAccount получил index =', index, typeof index);
  
  store.removeAccount(index);
  delete errors[index];
  delete passwordVisible[index];
  
  
}

/**
 * Обновляет одну из полей (login, password, type). Сразу сохраняет после валидации.
 * @param {number} index
 * @param {string} field
 * @param {any} value
 */
function updateField(index, field, value) {
  if (field === 'login') {
    const { isValid, errorText } = validateLogin(value);
    if (!errors[index]) errors[index] = {};
    errors[index].login = isValid ? '' : errorText;
    if (isValid) {
      store.updateAccount(index, field, value);
    }
  }

  if (field === 'password') {
    const account = store.accounts[index];
    if (account && account.type === 'Локальная') {
      const { isValid, errorText } = validatePassword(value);
      if (!errors[index]) errors[index] = {};
      delete errors[index]?.password;
      errors[index].password = isValid ? '' : errorText;
      console.log( "isValid", isValid)
      if (isValid) {
        store.updateAccount(index, field, value);
          delete errors[index]?.password;
      }
    } else {
      // Если тип не “Локальная”, сбросим ошибку и просто обновим
      delete errors[index]?.password;
      store.updateAccount(index, field, value);
    }
  }

  if (field === 'type') {
    store.updateAccount(index, field, value);
    if (value === 'LDAP') {
      // При переключении на LDAP сбросим ошибку пароля
      delete errors[index]?.password;
    }
  }
}

/**
 * Валидация без немедленного сохранения (вызывается при blur или при смене type)
 * @param {number} index
 * @param {string} field
 * @param {any} value
 */
function validateField(index, field, value) {
  if (!errors[index]) errors[index] = {};

  if (field === 'login') {
    const { isValid, errorText } = validateLogin(value);
    errors[index].login = isValid ? '' : errorText;
  }

  if (field === 'password') {
    const account = store.accounts[index];
    if (account && account.type === 'Локальная') {
      const { isValid, errorText } = validatePassword(value);
      errors[index].password = isValid ? '' : errorText;
    } else {
      errors[index].password = '';
      
    }
  }
}

/**
 * Переключает видимость пароля по индексу
 */
function togglePasswordVisibility(index) {
  passwordVisible[index] = !passwordVisible[index];
}

/**
 * Обновляет поле label: value должен быть массивом объектов { text }
 * @param {number} index
 * @param {Array<{ text: string }>} newLabelArr
 */
function updateLabel(index, newLabelArr) {
  console.log('App.vue/updateLabel получил index =', index, typeof index);
  store.updateAccount(index, 'label', newLabelArr);
}
</script>

<style>
.accounts-form {
  max-width: 800px;
  margin: 0 auto;
  font-family: Arial, sans-serif;
  padding: 16px;
}
</style>
