<template>
  <div>
    <!-- Заголовок таблицы -->
    <AccountsTableHeading />

    <!-- Строки таблицы -->
    <AccountsTableRows
      v-for="(acct, idx) in accounts"
      :key="acct.id"
      :index="idx"
      :account="acct"
      :fieldErrors="errors[idx] || {}"
      :passwordVisible="passwordVisible[idx] || false"
      @update-label="(i, newArr) => $emit('update-label', i, newArr)"
      @update-field="(i, field, val) => $emit('update-field', i, field, val)"
      @validate-field="(i, field, val) => $emit('validate-field', i, field, val)"
      @toggle-password="(i) => $emit('toggle-password', i)"
      @remove="(i) => $emit('remove', i)"
    />
  </div>
</template>

<script>
import AccountsTableHeading from '@/components/AccountsTable/AccountsTableHeading.vue';
import AccountsTableRows   from '@/components/AccountsTable/AccountsTableRows.vue';

export default {
  name: 'AccountsTableMain',
  components: {
    AccountsTableHeading,
    AccountsTableRows
  },
  props: {
    /**
     * accounts: массив объектов учётных записей
     * Каждый элемент:
     *   {
     *     id: Number,
     *     label: Array<{ text: String }>,
     *     type: String,       // 'LDAP' или 'Локальная'
     *     login: String,
     *     password: String
     *   }
     */
    accounts: {
      type: Array,
      required: true
    },
    /**
     * errors: объект ошибок валидации
     * Ключи — индексы записей (Number),
     * Значения — { login?: String, password?: String }
     */
    errors: {
      type: Object,
      required: true
    },
    /**
     * passwordVisible: объект видимости пароля
     * Ключи — индексы записей (Number),
     * Значения — Boolean (true = показывать текстом, false = скрывать)
     */
    passwordVisible: {
      type: Object,
      required: true
    }
  },
  emits: [
    // 1) сохранить новый массив label: (index: Number, newLabelArr: Array<{text:String}>)
    'update-label',
    // 2) сохранить конкретное поле: (index: Number, field: String, value: String | Array<{text:String}>)
    'update-field',
    // 3) проверить поле без сохранения: (index: Number, field: String, value: String)
    'validate-field',
    // 4) переключить видимость пароля: (index: Number)
    'toggle-password',
    // 5) удалить запись: (index: Number)
    'remove'
  ]
};
</script>

<style scoped>
/* При необходимости оставьте здесь стили из прежней версии */
</style>
