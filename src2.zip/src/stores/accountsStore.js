// src/stores/accountsStore.js

import { defineStore } from 'pinia';

export const useAccountsStore = defineStore('accounts', {
  state: () => ({
    // При загрузке: либо из localStorage, либо пустой массив
    accounts: JSON.parse(localStorage.getItem('accounts')) || []
  }),
  actions: {
    /**
     * Добавляет новую учетную запись с полями по умолчанию:
     * label — пустой массив объектов { text },
     * type — 'LDAP',
     * login, password — пустые строки.
     */
    addAccount() {
      this.accounts.push({
        id: Date.now(),
        label: [],       // Массив объектов вида { text: string }
        type: 'LDAP',    // «LDAP» или «Локальная»
        login: '',
        password: ''
      });
      this._saveToLocalStorage();
    },

    /**
     * Обновляет поле заданной учетной записи:
     * - field === 'label': value должен быть массивом { text: string }[]
     * - field === 'type': value — строка 'LDAP' или 'Локальная'
     *   (и при переходе в 'LDAP' сбрасываем password = '')
     * - иначе (login или password) — просто строка.
     *
     * @param {number} index
     * @param {string} field
     * @param {*} value
     */
    updateAccount(index, field, value) {
      const acct = this.accounts[index];
      if (!acct) return;

      if (field === 'label') {
        acct.label = value; // ожидаем массив объектов { text }
      } else if (field === 'type') {
        acct.type = value;
        if (value === 'LDAP') {
          acct.password = '';
        }
      } else {
        // login или password
        acct[field] = value;
      }

      this._saveToLocalStorage();
    },

    /**
     * Удаляет учетную запись по индексу
     * @param {number} index
     */
    removeAccount(index) {
      if (!this.accounts[index]) return;
      this.accounts.splice(index, 1);
      this._saveToLocalStorage();
    },

    /**
     * Сохраняет массив this.accounts в localStorage.
     * Чтобы удалить все вложенные Proxy из Vue, проходим по каждому элементу
     * и делаем JSON.parse(JSON.stringify(...)).
     */
    _saveToLocalStorage() {
      const rawAccounts = this.accounts.map((acct) =>
        JSON.parse(JSON.stringify(acct))
      );
      localStorage.setItem('accounts', JSON.stringify(rawAccounts));
    }
  }
});
