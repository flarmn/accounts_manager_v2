<template>
  <div class="accounts-form">
    <AccountsHeader @add="addAccount" />

    <InfoMessage />

    <AccountsTableMain
      :accounts="accounts"
      :errors="errors"
      :passwordVisible="passwordVisible"
      @update-label="updateLabel"
      @update-field="updateField"
      @validate-field="validateField"
      @toggle-password="togglePasswordVisibility"
      @remove="removeAccount"
    />
  </div>
</template>

<script setup>
import { computed, reactive } from 'vue';
import { useAccountsStore } from '@/stores/accountsStore';
import AccountsHeader from '@/components/AccountsHeader.vue';
import InfoMessage from '@/components/InfoMessage.vue';
import AccountsTableMain from '@/components/AccountsTable/AccountsTableMain.vue';
import { validateLogin, validatePassword } from '@/services/validators';

const store = useAccountsStore();
const accounts = computed(() => store.accounts);

// Ошибки по индексам: удаляем свойство ошибки, когда она устраняется
const errors = reactive({});

// Видимость пароля
const passwordVisible = reactive({});

function addAccount() {
  store.addAccount();
}

function removeAccount(index) {
  store.removeAccount(index);
  // После удаления строки стираем связанные ошибки
  delete errors[index];
  delete passwordVisible[index];
}

function updateField(index, field, value) {
  if (field === 'login') {
    const { isValid, errorText } = validateLogin(value);
    if (!errors[index]) errors[index] = {};
    if (!isValid) {
      errors[index].login = errorText;
    } else {
      // Убираем свойство login из ошибок, если всё ок
      delete errors[index].login;
      // Если после удаления внутри объекта больше нет полей, удаляем сам объект
      if (Object.keys(errors[index]).length === 0) {
        delete errors[index];
      }
      store.updateAccount(index, field, value);
    }
  }

  if (field === 'password') {
    const account = store.accounts[index];
    if (account && account.type === 'Локальная') {
      const { isValid, errorText } = validatePassword(value);
      if (!errors[index]) errors[index] = {};
      if (!isValid) {
        errors[index].password = errorText;
      } else {
        delete errors[index].password;
        if (Object.keys(errors[index]).length === 0) {
          delete errors[index];
        }
        store.updateAccount(index, field, value);
      }
    } else {
      // Если тип не Локальная, просто сбрасываем ошибку
      if (errors[index]) {
        delete errors[index].password;
        if (Object.keys(errors[index]).length === 0) {
          delete errors[index];
        }
      }
      store.updateAccount(index, field, value);
    }
  }

  if (field === 'type') {
    store.updateAccount(index, field, value);
    // При переключении на LDAP стираем возможную ошибку password
    if (value === 'LDAP' && errors[index]?.password) {
      delete errors[index].password;
      if (Object.keys(errors[index]).length === 0) {
        delete errors[index];
      }
    }
  }
}

function validateField(index, field, value) {
  if (!errors[index]) errors[index] = {};

  if (field === 'login') {
    const { isValid, errorText } = validateLogin(value);
    if (!isValid) {
      errors[index].login = errorText;
    } else {
      delete errors[index].login;
      if (Object.keys(errors[index]).length === 0) {
        delete errors[index];
      }
    }
  }

  if (field === 'password') {
    const account = store.accounts[index];
    if (account && account.type === 'Локальная') {
      const { isValid, errorText } = validatePassword(value);
      if (!isValid) {
        errors[index].password = errorText;
      } else {
        delete errors[index].password;
        if (Object.keys(errors[index]).length === 0) {
          delete errors[index];
        }
      }
    } else {
      // Если поле password не актуально (LDAP), просто удаляем ошибку
      if (errors[index]) {
        delete errors[index].password;
        if (Object.keys(errors[index]).length === 0) {
          delete errors[index];
        }
      }
    }
  }
}

function togglePasswordVisibility(index) {
  passwordVisible[index] = !passwordVisible[index];
}

function updateLabel(index, newLabelArr) {
  store.updateAccount(index, 'label', newLabelArr);
}
</script>

<style>
/* остальные стили без изменений */
</style>
